# Ream - Development

## Get started

- Clone the repository
- Check to do
- Make edits
- Document new features
- Commit and push back up

## Todo

- Work on import
- Create else+else if
- Fix multi-operator bug
- Fix function calls in functions crashing
- Write get started instructions
- Rewrite documentation
- Add casting

## Changelog

- Moved classes to separate files
- Allowed functions to return values
- Added more in-built functions
- Added abilty to declare sequence
- Added iteration through sequences, strings, intergers and booleans
- Get item at index of iterator 
```ream
x = ['hello', 'world', '1'] 
a = x(2)
Main.Write(a)
// or x[2]
```
