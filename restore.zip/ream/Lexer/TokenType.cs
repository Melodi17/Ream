﻿namespace Ream.Lexer
{
    public enum TokenType
    {
        String,
        Interger,
        Boolean,
        Operator,
        Value,
        Bracket,
        Function,
        Sequence,
        Newline,
        Null
    }
}
